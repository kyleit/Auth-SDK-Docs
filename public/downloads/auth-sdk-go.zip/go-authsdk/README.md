# Go Auth SDK

SDK hỗ trợ Login + Middleware (Gin, Fiber).

## Cài đặt
go get your-repo/go-authsdk

## Ví dụ Login
```go
client := client.NewAuthClient("https://auth.example.com")
resp, err := client.Login(context.Background(), "alice", "secret", "")
fmt.Println(resp.AccessToken)
```

# Gin Middleware
```
r := gin.Default()
authClient := client.NewAuthClient("https://auth.example.com")
r.Use(middleware.GinAuthMiddleware(authClient))

r.GET("/protected", func(c *gin.Context) {
  user := c.MustGet("user").(*client.IntrospectResponse)
  c.JSON(200, gin.H{"user": user.Username, "roles": user.Roles})
})
```

# Fiber Middleware

```
app := fiber.New()
authClient := client.NewAuthClient("https://auth.example.com")
app.Use(middleware.FiberAuthMiddleware(authClient))

app.Get("/protected", func(c *fiber.Ctx) error {
  user := c.Locals("user").(*client.IntrospectResponse)
  return c.JSON(user)
})
```